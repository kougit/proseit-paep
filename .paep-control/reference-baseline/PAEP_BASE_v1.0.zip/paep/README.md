# PAEP implementation repository baseline

This repository skeleton is derived from **PAEP v1.1** and the controlled implementation baseline. It is a reference structure for the first PAEP workspace, not a replacement for the controlled architecture specification.

## Baseline principles

(i) Product applications remain thin composition layers.
(ii) `@proseit/paep-contracts` is plain TypeScript and contains no Frappe or UI implementation details.
(iii) ERPNext/Frappe remains the strategic backend through `@proseit/frappe-sdk` and PMRA/product APIs.
(iv) Browser code never connects directly to ERP databases or analytical stores.
(v) Reporting uses governed semantic contracts and server-side authorization.
(vi) Environment differences are runtime configuration, not product source forks.
(vii) Package boundaries and public entry points are enforced in CI.

Exact dependency versions are pinned only after the first approved PAEP release manifest is created.
