import { ApplicationConfig, provideAppInitializer } from '@angular/core';
import { provideHttpClient, withInterceptors } from '@angular/common/http';
import { provideRouter } from '@angular/router';
import { routes } from './app.routes';
import { initialiseRuntimeConfig } from './core/runtime/runtime-config.initializer';

export const appConfig: ApplicationConfig = {
  providers: [
    provideHttpClient(withInterceptors([])),
    provideAppInitializer(initialiseRuntimeConfig),
    provideRouter(routes),
    // PAEP providers: runtime, identity, i18n, observability, offline, Frappe adapter, reporting gateway.
  ],
};
