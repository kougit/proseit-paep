import { Routes } from '@angular/router';

export const routes: Routes = [
  { path: '', pathMatch: 'full', redirectTo: 'workspace' },
  { path: 'workspace', loadComponent: () => import('./features/workspace/workspace.page').then(m => m.WorkspacePage) },
  { path: 'analytics', loadChildren: () => import('./features/analytics/analytics.routes').then(m => m.ANALYTICS_ROUTES) },
  { path: '**', loadComponent: () => import('@proseit/paep-enterprise').then(m => m.NotFoundPage) },
];
