import { inject } from '@angular/core';
import { RuntimeConfigService } from '@proseit/paep-platform';

export function initialiseRuntimeConfig(): Promise<void> {
  return inject(RuntimeConfigService).loadValidateAndFreeze('/config/runtime-config.json');
}
