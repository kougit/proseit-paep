import { Component } from '@angular/core';

@Component({
  selector: 'paep-reference-analytics-home',
  template: `<h1>Analytics</h1><p>Reference dashboard host.</p>`,
})
export class AnalyticsHomePage {}
