import { Routes } from '@angular/router';

export const ANALYTICS_ROUTES: Routes = [
  { path: '', loadComponent: () => import('./analytics-home.page').then(m => m.AnalyticsHomePage) },
];
