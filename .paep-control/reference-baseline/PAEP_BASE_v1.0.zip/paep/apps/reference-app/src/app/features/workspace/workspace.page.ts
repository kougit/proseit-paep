import { Component } from '@angular/core';

@Component({
  selector: 'paep-reference-workspace',
  template: `<h1>PAEP Reference Workspace</h1><p>Golden vertical slice placeholder.</p>`,
})
export class WorkspacePage {}
