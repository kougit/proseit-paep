# Initial ADR set

(i) ADR-001: Angular 22 active-major implementation baseline and upgrade policy.
(ii) ADR-002: Nx workspace orchestration with npm packages; no runtime dependency on Nx.
(iii) ADR-003: Product-neutral `paep-contracts` and Frappe adapter separation.
(iv) ADR-004: Signal-oriented local state and server-authoritative data.
(v) ADR-005: Runtime configuration schema and deploy-once/runtime-configure model.
(vi) ADR-006: Reporting semantic model and optional analytical store decision rule.
(vii) ADR-007: Default visualization adapter and replacement boundary.
(viii) ADR-008: CSP/Trusted Types/AOT production security profile.
(ix) ADR-009: Offline command queue and idempotency model.
(x) ADR-010: Package publication, partial-Ivy format and release compatibility matrix.
