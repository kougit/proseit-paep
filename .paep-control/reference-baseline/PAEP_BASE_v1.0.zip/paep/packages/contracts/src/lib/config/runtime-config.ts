export type DeploymentProfile = 'cloud-saas' | 'private-cloud' | 'on-premise';
export type IdentityMode = 'frappe-session' | 'oidc' | 'sso-proxy';
export type OfflineProfile = 'none' | 'drafts-only' | 'bounded-commands';

export interface RuntimeConfig {
  readonly schemaVersion: '1.0';
  readonly product: { readonly id: string; readonly name: string; readonly release: string; readonly brandProfile?: string; };
  readonly deployment: { readonly environment: 'development'|'test'|'staging'|'production'; readonly profile: DeploymentProfile; readonly basePath: string; };
  readonly backend: { readonly apiBaseUrl: string; readonly realtimeUrl?: string|null; readonly fileBaseUrl?: string|null; readonly compatibility: { readonly apiContract: string; readonly minimumPaep?: string; readonly maximumPaep?: string|null; }; };
  readonly identity: { readonly mode: IdentityMode; readonly issuer?: string|null; readonly clientId?: string|null; readonly scopes?: readonly string[]; };
  readonly localisation: { readonly defaultLocale: string; readonly supportedLocales: readonly string[]; readonly rtlLocales?: readonly string[]; };
  readonly features: { readonly capabilityDiscovery: 'server'|'manifest'; readonly uiHints?: Readonly<Record<string, boolean|string|number>>; };
  readonly telemetry: { readonly enabled: boolean; readonly endpoint?: string|null; readonly sampleRate?: number; };
  readonly analytics: { readonly enabled: boolean; readonly reportingBaseUrl?: string|null; readonly embeddedBi?: { readonly enabled?: boolean; readonly provider?: 'power-bi'|'other'; }; };
  readonly pwa: { readonly enabled: boolean; readonly offlineProfile: OfflineProfile; };
  readonly security?: { readonly trustedTypesPolicyName?: string; readonly cspProfile?: string; };
}
