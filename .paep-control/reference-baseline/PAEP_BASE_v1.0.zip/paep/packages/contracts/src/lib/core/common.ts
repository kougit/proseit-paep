export type EntityId = string;
export type CorrelationId = string;
export type IsoDateTime = string;

export interface PageRequest { cursor?: string; limit?: number; }
export interface PageInfo { nextCursor?: string; total?: number; }
export interface PagedResult<T> { items: readonly T[]; page: PageInfo; correlationId?: CorrelationId; }

export type PaepErrorCode = 'AUTHENTICATION' | 'AUTHORIZATION' | 'VALIDATION' | 'CONFLICT' | 'RATE_LIMIT' | 'UNAVAILABLE' | 'UNEXPECTED';
export interface PaepError {
  code: PaepErrorCode;
  messageKey: string;
  correlationId?: CorrelationId;
  fieldErrors?: Readonly<Record<string, readonly string[]>>;
  retryable?: boolean;
}
