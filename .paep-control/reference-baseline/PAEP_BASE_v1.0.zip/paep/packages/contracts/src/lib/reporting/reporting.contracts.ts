import type { CorrelationId, PageInfo } from '../core/common';

export type FieldDataType = 'string'|'number'|'integer'|'boolean'|'date'|'datetime'|'currency'|'percentage';
export type VisualType = 'kpi'|'table'|'bar'|'line'|'area'|'pie'|'scatter'|'heatmap'|'waterfall'|'funnel'|'combo';

export interface DimensionDefinition { key: string; labelKey: string; dataType: FieldDataType; hierarchy?: readonly string[]; filterable?: boolean; }
export interface MetricDefinition { key: string; labelKey: string; dataType: FieldDataType; format?: string; descriptionKey?: string; }
export interface DatasetDescriptor {
  id: string; version: string; labelKey: string;
  dimensions: readonly DimensionDefinition[];
  metrics: readonly MetricDefinition[];
  defaultTimeDimension?: string;
  freshnessPolicy?: { targetSeconds?: number; displayedToUser?: boolean; };
}
export type FilterOperator = 'eq'|'neq'|'in'|'notIn'|'gt'|'gte'|'lt'|'lte'|'between'|'contains'|'startsWith'|'isNull'|'isNotNull';
export interface ReportFilter { field: string; operator: FilterOperator; value?: unknown; }
export interface ReportSort { field: string; direction: 'asc'|'desc'; }
export interface ReportQuery {
  datasetId: string;
  metrics: readonly string[];
  dimensions?: readonly string[];
  filters?: readonly ReportFilter[];
  sort?: readonly ReportSort[];
  cursor?: string;
  limit?: number;
  parameters?: Readonly<Record<string, unknown>>;
}
export interface ReportColumn { key: string; label: string; dataType: FieldDataType; format?: string; }
export interface DataFreshness { asOf: string; source: 'operational'|'analytical'|'hybrid'; stale?: boolean; }
export interface ReportResult<Row extends Readonly<Record<string, unknown>> = Readonly<Record<string, unknown>>> {
  columns: readonly ReportColumn[];
  rows: readonly Row[];
  page?: PageInfo;
  totals?: Readonly<Record<string, unknown>>;
  freshness: DataFreshness;
  correlationId: CorrelationId;
}
export interface DrillRequest { reportId: string; visualId: string; sourceContext: Readonly<Record<string, unknown>>; target: string; }
export interface ExportRequest { reportId: string; format: 'csv'|'xlsx'|'pdf'; query: ReportQuery; }
export interface ExportJob { id: string; status: 'queued'|'running'|'succeeded'|'failed'|'expired'; progress?: number; downloadUrl?: string; expiresAt?: string; correlationId?: CorrelationId; }
export interface VisualDefinition { id: string; type: VisualType; titleKey: string; query: ReportQuery; crossFilter?: boolean; drillTargets?: readonly string[]; }
export interface DashboardDefinition { id: string; version: string; titleKey: string; visuals: readonly VisualDefinition[]; globalFilters?: readonly ReportFilter[]; }

export interface ReportingGateway {
  getDataset(id: string): Promise<DatasetDescriptor>;
  execute(query: ReportQuery): Promise<ReportResult>;
  drill(request: DrillRequest): Promise<ReportResult>;
  requestExport(request: ExportRequest): Promise<ExportJob>;
  getExportJob(id: string): Promise<ExportJob>;
}
