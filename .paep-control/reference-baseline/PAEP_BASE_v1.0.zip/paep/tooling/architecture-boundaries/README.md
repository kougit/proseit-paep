# PAEP package boundary rules

(i) `layer:base` packages (`contracts`, `foundation`) never depend upward.
(ii) `layer:platform` may depend only on `layer:base` and approved third-party libraries.
(iii) `layer:interaction` may depend on `layer:platform` and `layer:base`.
(iv) `layer:experience` may depend on lower layers, never on applications.
(v) `layer:app` may compose all approved PAEP packages.
(vi) Cross-package imports use package public entry points only; deep imports are blocked.
(vii) Circular dependencies are release-blocking.
(viii) `@proseit/paep-contracts` has no Angular, Frappe, DOM or charting-library dependency.
(ix) `@proseit/paep-analytics` has no direct ERPNext/Frappe persistence dependency.
