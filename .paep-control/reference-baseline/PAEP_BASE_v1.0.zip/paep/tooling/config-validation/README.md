# Runtime configuration validation

Canonical schema: `config/runtime-config.schema.json`.

CI validates every deployment configuration against the schema. The production build bundles a generated standalone validator so startup validation does not require dynamic schema compilation. Invalid or incompatible configuration must stop protected application startup and display a safe supportable error screen with a correlation/configuration identifier.
