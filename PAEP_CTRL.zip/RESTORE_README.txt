PAEP control restore pack

Copy/extract these contents directly into the ROOT of the proseit-paep repository.
Expected result:
  .gitignore
  .paep-control/

Do not place them inside an extra PAEP_CTRL directory.
